$(".runtasclor").click(function(){
	window.location.href="javascript:history.back();"
})