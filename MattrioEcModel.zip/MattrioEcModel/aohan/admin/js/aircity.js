

var commoncitys=new Array();

var citys=new Array();




