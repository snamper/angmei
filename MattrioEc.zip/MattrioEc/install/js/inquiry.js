// localStorage.setItem("network","http://192.168.1.112:8080/MattrioEc");
localStorage.setItem("network","http://www.51macc.com:8080/MattrioEc");

var network = localStorage.getItem("network");
var carname = localStorage.getItem("carname");
var carput = localStorage.getItem("carput");
var carpai = localStorage.getItem("carpai");


$(".container").hide();
$("table").hide();
$(".contbox").hide();

//获取通过url传的参数
 function getUrlParam(name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)"); //构造一个含有目标参数的正则表达式对象
    var r = window.location.search.substr(1).match(reg);  //匹配目标参数
    if (r != null) return decodeURI(r[2]); return null; //返回参数值
}
var carall = getUrlParam('?carall');

if(carall == null){
	$(".carm").html("选择车型 &gt;");
}else{
	$(".carm").html(carall)
}

$(".runpseltex").hide();
//获取年份

$(".carm").click(function(){
	window.location.href="./select/select.html";
})



$(".yearm").click(function(){
	$(".yearheader").show();
	$("#container").hide();
	$("table").hide();
	$(".contbox").hide();
	$(".yearheader ul").html("");

	var str = [2017,2016,2015,2014,2013,2012,2011,2010,2009,2008,2007,2006,2005,2004,2003,2002,2001,2000,1999,1998];
		$.each(str,function(key,value){
			//console.log(value);
			$("<li>").html(value).appendTo(".yearheader ul");
		})

		$(".yearheader ul li").click(function(){
			//console.log($(this).html());
			$(".yearheader").hide();
			$(".yearm").html("");
			$(".yearm").html($(this).html());
			if($(this).html() > 2015){
				$(".city").hide();
				$(".provincem").html("选择省份 &gt;");
				$(".citym").html("");
			}else{
				$(".city").show();
				$(".provincem").html("选择省份 &gt;");
				$(".citym").html("选择地级市 &gt;");
			}
			

		})
})

$(".yeartmk span").click(function(){
	$(".yearheader").hide();
	$(".provinceheader").hide();
	$(".cityheader").hide();
})



var num;

//选择省份
$(".provincem").click(function(){
	$("#container").hide();
	$("table").hide();
	if($(".yearm").html() == "选择年份 &gt;"){
		alert("请选择您要查询的年份");
		return false;
	}
	$(".provinceheader").show();
	$(".provincecar ul li").click(function(){
		$(".provinceheader").hide();
		$(".provincem").html($(this).html());
		num = $(this).index()+1;


		$(".citym").html("选择地级市 &gt;")
	})
		
	
})

var n ;

$(".citym").click(function(){
	$("#container").hide();
	$("table").hide();
	$(".cityheader ul").html("");

	if($(".provincem").html() == "选择省份 &gt;"){
		alert("请选择您要查询的省份");
		return false;
	}


	$(".cityheader").show();
	//console.log($(".provincem").html());

	$.ajax({
		type:"post",
		url:network+"/BaoYouLiangIntface/getCity",
		data:{
			"address_id":num
		},
		dataType:"json",
		cache: false,
		crossDomain: true == !(document.all),
		success:function(data){
			//console.log(data);
			$.each(data,function(key,value){
				$("<li>").html(value.address_name).appendTo(".cityheader ul");
			})
			$(".cityheader ul li").click(function(){
				//console.log($(this).index());
				n = data[$(this).index()].address_id;
				
				$(".cityheader").hide();
				$(".citym").html($(this).html());
			})
		}
	})

})




$(".button button").click(function(){
	if($(".carm").html() == "选择车型 &gt;"){
		alert("请选择您要查询的条件");
		return false;
	}
	if($(".provincem").html() == "选择省份 &gt;"){
		alert("请选择您要查询的省份");
		return false;
	}
	if($(".provincem").html() == "选择省份 &gt;"){
		alert("请选择您要查询的省份");
		return false;
	}
	$("#loading").show();
	/*$("#container").show();
	$("table").show();
	$(".contbox").show();*/
	$.ajax({
		type: "post",
		url: network+"/BaoYouLiangIntface/getInstallationBase",
		data: {
			"shengfen":num,
			"city":n,
			"Manufactur":carname,
			"VehicleNam":carput,
			"capacity":carpai,
			"year": $(".yearm").html()
		},
		dataType: "json",
		cache: false,
		crossDomain: true == !(document.all),
		success: function(data) {
		$("#loading").hide();
			
			$("#container").show();
			$("table").show();
			$(".contbox").show();

			if(data.car_info.byl1 == 0){
				$("#container").hide();
				$(".contbox").hide();
			}

			//console.log(data);
			

			$('#car_icon').attr('src','http://oqebrtdnm.bkt.clouddn.com/' + data.car_info.car_icon+'');
			$('#car_Manufactur').html(data.car_info.Manufactur);
			$('#car_VehicleNam').html(data.car_info.VehicleNam);
			$('#car_capacity').html(data.car_info.capacity);
			$('#car_year').html(data.car_info.year);
			$('#car_byl1').html(data.car_info.byl1);
			$('#car_byl2').html(data.car_info.byl2);
			$('#car_byl_name1').html(data.car_info.byl_name1);
			$('#car_byl_name2').html(data.car_info.byl_name2);

			$('#container').highcharts({
				chart: {
					plotBackgroundColor: null,
					plotBorderWidth: null,
					plotShadow: false
				},
				colors: ['#90ed7d', '#f7a35c'],
				title: {
					text: data.shengfen
				},
				tooltip: {
					headerFormat: '{series.name}<br>',
					pointFormat: '{point.name}: <b>{point.percentage:.1f}%</b>'
				},
				plotOptions: {
					pie: {
						allowPointSelect: true,
						cursor: 'pointer',
						dataLabels: {
							enabled: true,
							format: '<b>{point.name}</b>: {point.percentage:.1f} %',
							style: {
								color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
							}
						}
					}
				},
				series: data.list
			});
		},
		error: function(data) {
			//console.log(data);
		}
	});

});
	
